<?php
return array (
  'Wiki page' => 'Wikipagina',
);
