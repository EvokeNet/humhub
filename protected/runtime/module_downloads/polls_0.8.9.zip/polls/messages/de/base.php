<?php
return array (
  'Polls' => 'Umfragen',
);
