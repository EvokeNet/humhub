<?php
return array (
  'Polls' => 'アンケート',
);
