<?php
return array (
  '{userName} created a new {question}.' => '{userName} ha creat una nova {question}.',
);
