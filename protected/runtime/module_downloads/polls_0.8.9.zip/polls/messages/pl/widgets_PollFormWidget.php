<?php
return array (
  'Ask' => 'Zapytaj',
);
