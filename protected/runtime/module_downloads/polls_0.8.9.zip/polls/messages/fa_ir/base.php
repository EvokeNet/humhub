<?php
return array (
  'Polls' => 'نظرسنجی‌ها',
);
