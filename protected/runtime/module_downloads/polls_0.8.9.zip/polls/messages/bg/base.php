<?php
return array (
  'Polls' => 'Анкети',
);
