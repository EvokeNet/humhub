<?php
return array (
  'Polls' => 'Anketler',
);
