<?php
return array (
  'Sign up now' => 'Accedi ora',
);
