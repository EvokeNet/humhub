<?php
return array (
  'Message' => 'Messaggio',
);
