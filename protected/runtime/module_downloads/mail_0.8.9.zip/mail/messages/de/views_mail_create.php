<?php
return array (
  'Add recipients' => 'Empfänger hinzufügen',
  'Close' => 'Schließen',
  'New message' => 'Neue Nachricht',
  'Send' => 'Senden',
);
