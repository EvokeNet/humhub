<?php
return array (
  'Message' => 'Wiadomość ',
  'Recipient' => 'Odbiorca ',
  'Subject' => 'Temat ',
  'You cannot send a email to yourself!' => 'Nie możesz wysłać wiadomości do samego siebie!',
);
