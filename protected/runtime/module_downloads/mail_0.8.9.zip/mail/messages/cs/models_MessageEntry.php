<?php
return array (
  'New message in discussion from %displayName%' => 'Nová zpráva v konverzaci od uživatele %displayName%',
);
