<?php
return array (
  'Add recipients' => 'Přidat příjemce',
  'Close' => 'Zavřít',
  'New message' => 'Nová zpráva',
  'Send' => 'Poslat',
);
