<?php
return array (
  'Add recipients' => 'Tilføjet modtagere',
  'Close' => 'Luk',
  'New message' => 'Ny besked',
  'Send' => 'Send',
);
