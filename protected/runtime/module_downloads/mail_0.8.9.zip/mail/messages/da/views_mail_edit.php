<?php
return array (
  'Edit message entry' => 'Rediger besked',
  'Save' => 'Gem',
);
