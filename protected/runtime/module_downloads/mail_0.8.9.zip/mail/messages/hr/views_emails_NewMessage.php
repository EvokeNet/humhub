<?php
return array (
  '<strong>New</strong> message' => '',
  'Reply now' => '',
  'sent you a new message:' => '',
);
