<?php
return array (
  'Groups' => '',
  'Members' => '',
  'Spaces' => '',
  'User Posts' => '',
);
