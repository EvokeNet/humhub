<?php
return array (
  'Messages' => 'الرسائل',
);
