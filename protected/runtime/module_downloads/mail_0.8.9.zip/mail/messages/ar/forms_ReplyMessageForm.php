<?php
return array (
  'Message' => 'الرسالة',
);
