<?php
return array (
  'Sign up now' => '今すぐ登録',
);
