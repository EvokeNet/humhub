<?php
return array (
  'Message' => 'メッセージ',
);
