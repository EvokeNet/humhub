<?php
return array (
  'Messages' => 'Съобщения',
);
