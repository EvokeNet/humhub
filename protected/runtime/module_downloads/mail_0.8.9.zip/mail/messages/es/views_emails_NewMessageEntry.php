<?php
return array (
  'sent you a new message in' => 'te ha enviado un nuevo mensaje en',
);
