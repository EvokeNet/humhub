<?php
return array (
  'Messages' => 'Mensajes',
);
