<?php
return array (
  'Messages' => 'Berichten',
);
